# Honeypot Proxy

Honeypot proxy is tool for redirectiong SSH session from local computer
to server of HaaS with additional information.

More information on https://haas.nic.cz

## Development

To prepare your dev envrionment run this command:

    make prepare-dev

To run tests or lint use this command:

    make test
    make lint
